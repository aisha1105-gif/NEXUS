/*
 * Sonatype Nexus (TM) Open Source Version
 * Copyright (c) 2008-present Sonatype, Inc.
 * All rights reserved. Includes the third-party code listed at http://links.sonatype.com/products/nexus/oss/attributions.
 *
 * This program and the accompanying materials are made available under the terms of the Eclipse Public License Version 1.0,
 * which accompanies this distribution and is available at http://www.eclipse.org/legal/epl-v10.html.
 *
 * Sonatype Nexus (TM) Professional Version is available from Sonatype, Inc. "Sonatype" and "Sonatype Nexus" are trademarks
 * of Sonatype, Inc. Apache Maven is a trademark of the Apache Software Foundation. M2eclipse is a trademark of the
 * Eclipse Foundation. All other trademarks are the property of their respective owners.
 */
package org.sonatype.nexus.repository.apt.internal;

/**
 * @since 3.17
 */
public class PackageName
{
  private PackageName() {
    throw new IllegalAccessError("Utility class");
  }

  public static final String PACKAGES = "Packages";

  public static final String PACKAGES_GZ = "Packages.gz";

  public static final String PACKAGES_BZ2 = "Packages.bz2";

  public static final String PACKAGES_XZ = "Packages.xz";
}
